interface User {
    id: number;
    display_name?: string;
    // Add other user fields as needed
}

export default User;